﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Windows.Forms;

using System.Configuration;
using System.Data.SqlClient;
using System.Collections;

namespace Invoice_Application_Project.Models
{
	public class Service
	{
		//SQL connection
		SqlConnection connection;
		string connectionString = ConfigurationManager.ConnectionStrings["Invoice_Application_Project.Properties.Settings.InvoiceDatabaseConnectionString"].ConnectionString;

		//Fields
		private int id;
		private string name;
		private decimal price;


		//Constructor
		public Service() {

		}

		//Used for Ticket 14 method for making a list type of this class
		private Service(int idInput, string nameInput) {

			id = idInput;
			name = nameInput;

		}

		//Properties
		public int ServiceId {

			get { return id; }
			set { id = value; }
		}

		public string ServiceName {

			get { return name; }
			set { name = value; }
		}
		public decimal ServicePrice {

			get { return price; }
			set { price = value; }
		}


		//Methods

		/// <summary>
		/// Show list of services - Ticket 7
		/// </summary>
		public ArrayList ShowListServices()
		{
			ArrayList arrayServiceList = new ArrayList();

			//comboBox_ChooseService.Items.Clear(); TO CLEAR AGAIN

			//SQL
			connection = new SqlConnection(connectionString);
			connection.Open();

			string sqlQuery_DisplayServices = "SELECT serviceName FROM Service;";

			SqlCommand cmd = new SqlCommand(sqlQuery_DisplayServices, connection);
			SqlDataReader read = cmd.ExecuteReader();

			//Reads all list of service in the database
			while (read.Read())
			{
				arrayServiceList.Add(read.GetValue(0).ToString());
			}

			//Close connection
			connection.Close();

			//Return
			return arrayServiceList;
		}


		/// <summary>
		/// Add the chosen service in the list view and ServiceChosen table database - Ticket 8
		/// </summary>
		public ListViewItem AddService(ListViewItem item)
		{

			//SQL
			connection = new SqlConnection(connectionString);
			connection.Open();

			string sqlQuery_GetServicePrice = "SELECT serviceName, price FROM Service;";

			SqlCommand cmd = new SqlCommand(sqlQuery_GetServicePrice, connection);
			SqlDataReader read = cmd.ExecuteReader();

			//Reads all the records
			while (read.Read())
			{
				//If the name is the same as the item, get and add price
				if (read.GetValue(0).ToString() == item.Text)
				{

					//get Price
					item.SubItems.Add(string.Format("{0:0.00}", read.GetValue(1)));

					break;
				}
			}

			//Close connection
			connection.Close();

			return item;

		}


		/// <summary>
		/// Ticket - 14 (Save Chosen Service)
		/// </summary>
		public void AddRecord_ServiceChosen(int currentCustomer, int currentInvoiceId, ListView items)
		{
			//SQL
			connection = new SqlConnection(connectionString);
			connection.Open();

			//List of services in arraylist
			List<Service> listOfServices = new List<Service>();


			string sqlQuery_GetServiceId = "SELECT serviceId, serviceName FROM Service;";

			SqlCommand cmd1 = new SqlCommand(sqlQuery_GetServiceId, connection);

			SqlDataReader read = cmd1.ExecuteReader();

			//Gets all list of services from database and store into List
			while (read.Read()){

				listOfServices.Add( new Service(Convert.ToInt32(read.GetValue(0)), read.GetValue(1).ToString()));
			}
			connection.Close(); //Closed for cmd1


			//Adding the place holder value for service Id

			for (int i = 0; i < listOfServices.Count; i++)
				{
					foreach (ListViewItem list in items.Items)
					{
						//If the Name is the same as the listview items of chosen services
						if (listOfServices[i].ServiceName == list.SubItems[0].Text)
						{
							connection.Open(); //Open for cmd
							string sqlQuery_InsertRecord = "INSERT INTO ServiceChosen (serviceId, customerId, invoiceRecordId) VALUES (@serviceChosen, @currentCustomer, @invoiceRecordId);";
							SqlCommand cmd = new SqlCommand(sqlQuery_InsertRecord, connection);

							//get service Id
							cmd.Parameters.AddWithValue("@serviceChosen", listOfServices[i].ServiceId);

							//Adding the place holder values for customer id and invoice number
							cmd.Parameters.AddWithValue("@currentCustomer", currentCustomer);
							cmd.Parameters.AddWithValue("@invoiceRecordId", currentInvoiceId);


							//Insert record in database
							cmd.ExecuteNonQuery();

							connection.Close(); //Close for cmd
							
						}

					}

			}

		}

		/// <summary>
		/// Calculate total price of added service - Ticket 011
		/// </summary>
		public decimal CalculatePrice(ListView item)
		{

			decimal currentPrice = 0m;

			foreach (ListViewItem list in item.Items)
			{
				currentPrice += Convert.ToDecimal(list.SubItems[1].Text);
			}
			return currentPrice;

		}


		/// <summary>
		///  - Apply Discount - Ticket 019
		/// </summary>
		/// <returns></returns>
		public decimal CalculateDiscountPrice(string inputCurrentPrice, decimal discountVal)
		{

			//Ticket 19 - Apply Disocunt
			decimal totalDiscountedPrice = 0m;

			decimal currentPrice = Convert.ToDecimal(inputCurrentPrice);

			decimal discountValue = discountVal / 100;

			totalDiscountedPrice = currentPrice - (currentPrice * discountValue);

			return totalDiscountedPrice ;
		}





	}

	public class CopyOfService
	{
		//SQL connection
		SqlConnection connection;
		string connectionString = ConfigurationManager.ConnectionStrings["Invoice_Application_Project.Properties.Settings.InvoiceDatabaseConnectionString"].ConnectionString;

		//Fields
		private int id;
		private string name;
		private decimal price;


		//Constructor
		public CopyOfService()
		{

		}

		//Used for Ticket 14 method for making a list type of this class
		private CopyOfService(int idInput, string nameInput)
		{

			id = idInput;
			name = nameInput;

		}

		//Properties
		public int ServiceId
		{

			get { return id; }
			set { id = value; }
		}

		public string ServiceName
		{

			get { return name; }
			set { name = value; }
		}
		public decimal ServicePrice
		{

			get { return price; }
			set { price = value; }
		}


		//Methods

		/// <summary>
		/// Show list of services - Ticket 7
		/// </summary>
		public ArrayList ShowListServices()
		{
			ArrayList arrayServiceList = new ArrayList();

			//comboBox_ChooseService.Items.Clear(); TO CLEAR AGAIN

			//SQL
			connection = new SqlConnection(connectionString);
			connection.Open();

			string sqlQuery_DisplayServices = "SELECT serviceName FROM CopyOfService;";

			SqlCommand cmd = new SqlCommand(sqlQuery_DisplayServices, connection);
			SqlDataReader read = cmd.ExecuteReader();

			//Reads all list of service in the database
			while (read.Read())
			{
				arrayServiceList.Add(read.GetValue(0).ToString());
			}

			//Close connection
			connection.Close();

			//Return
			return arrayServiceList;
		}


		/// <summary>
		/// Add the chosen service in the list view and ServiceChosen table database - Ticket 8
		/// </summary>
		public ListViewItem AddService(ListViewItem item)
		{

			//SQL
			connection = new SqlConnection(connectionString);
			connection.Open();

			string sqlQuery_GetServicePrice = "SELECT serviceName, price FROM CopyOfService;";

			SqlCommand cmd = new SqlCommand(sqlQuery_GetServicePrice, connection);
			SqlDataReader read = cmd.ExecuteReader();

			//Reads all the records
			while (read.Read())
			{
				//If the name is the same as the item, get and add price
				if (read.GetValue(0).ToString() == item.Text)
				{

					//get Price
					item.SubItems.Add(string.Format("{0:0.00}", read.GetValue(1)));

					break;
				}
			}

			//Close connection
			connection.Close();

			return item;

		}


		/// <summary>
		/// Ticket - 14 (Save Chosen CopyOfService)
		/// </summary>
		public void AddRecord_ServiceChosen(int currentCustomer, int currentInvoiceId, ListView items)
		{
			//SQL
			connection = new SqlConnection(connectionString);
			connection.Open();

			//List of services in arraylist
			List<CopyOfService> listOfServices = new List<CopyOfService>();


			string sqlQuery_GetServiceId = "SELECT serviceId, serviceName FROM CopyOfService;";

			SqlCommand cmd1 = new SqlCommand(sqlQuery_GetServiceId, connection);

			SqlDataReader read = cmd1.ExecuteReader();

			//Gets all list of services from database and store into List
			while (read.Read())
			{

				listOfServices.Add(new CopyOfService(Convert.ToInt32(read.GetValue(0)), read.GetValue(1).ToString()));
			}
			connection.Close(); //Closed for cmd1


			//Adding the place holder value for service Id

			for (int i = 0; i < listOfServices.Count; i++)
			{
				foreach (ListViewItem list in items.Items)
				{
					//If the Name is the same as the listview items of chosen services
					if (listOfServices[i].ServiceName == list.SubItems[0].Text)
					{
						connection.Open(); //Open for cmd
						string sqlQuery_InsertRecord = "INSERT INTO ServiceChosen (serviceId, customerId, invoiceRecordId) VALUES (@serviceChosen, @currentCustomer, @invoiceRecordId);";
						SqlCommand cmd = new SqlCommand(sqlQuery_InsertRecord, connection);

						//get service Id
						cmd.Parameters.AddWithValue("@serviceChosen", listOfServices[i].ServiceId);

						//Adding the place holder values for customer id and invoice number
						cmd.Parameters.AddWithValue("@currentCustomer", currentCustomer);
						cmd.Parameters.AddWithValue("@invoiceRecordId", currentInvoiceId);


						//Insert record in database
						cmd.ExecuteNonQuery();

						connection.Close(); //Close for cmd

					}

				}

			}

		}

		/// <summary>
		/// Calculate total price of added service - Ticket 011
		/// </summary>
		public decimal CalculatePrice(ListView item)
		{

			decimal currentPrice = 0m;

			foreach (ListViewItem list in item.Items)
			{
				currentPrice += Convert.ToDecimal(list.SubItems[1].Text);
			}
			return currentPrice;

		}


		/// <summary>
		///  - Apply Discount - Ticket 019
		/// </summary>
		/// <returns></returns>
		public decimal CalculateDiscountPrice(string inputCurrentPrice, decimal discountVal)
		{

			//Ticket 19 - Apply Disocunt
			decimal totalDiscountedPrice = 0m;

			decimal currentPrice = Convert.ToDecimal(inputCurrentPrice);

			decimal discountValue = discountVal / 100;

			totalDiscountedPrice = currentPrice - (currentPrice * discountValue);

			return totalDiscountedPrice;
		}





	}
}
