﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using iText.Kernel.Pdf;
using iText.Layout;
using iText.Layout.Element;

namespace Invoice_Application_Project.Models
{
	public class Pdf
	{
		//Fields
		private string invoiceId;
		private DateTime date;
		private string customerName;
		private string email;
		private string address;
		private string postCode;
		private string notes;
		private string paymentDetails_1;
		private string paymentDetails_2;
		private string discountGiven;
		private string totalPrice;

		//Properties
		public string InvoiceId
		{
			get { return invoiceId; }
			set { invoiceId = value; }
		}
		public DateTime InvoiceDate
		{
			get { return date; }
			set { date = value; }
		}
		public string InvoiceCustomerName
		{
			get { return customerName; }
			set { customerName = value; }
		}
		public string InvoiceEmail
		{
			get { return email; }
			set { email = value; }
		}
		public string InvoiceAddress
		{
			get { return address; }
			set { address = value; }
		}
		public string InvoicePostcode
		{
			get { return postCode; }
			set { postCode = value; }
		}
		public string InvoiceNotes
		{
			get { return notes; }
			set { notes = value; }
		}

		public string InvoicePaymentDetails_1
		{
			get { return paymentDetails_1; }
			set { paymentDetails_1 = value; }
		}

		public string InvoicePaymentDetails_2
		{
			get { return paymentDetails_2; }
			set { paymentDetails_2 = value; }
		}

		public string InvoiceDiscountGiven
		{
			get { return discountGiven; }
			set { discountGiven = value; }
		}
		public string InvoiceTotalPrice
		{
			get { return totalPrice; }
			set { totalPrice = value; }
		}

		//Method

		/// <summary>
		/// Save all contents of invoice form to PDF - Ticket 13
		/// </summary>
		public void SaveInvoiceToPDF(ListView item) {

			try
			{
				var export_Folder = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

				var export_File = System.IO.Path.Combine(export_Folder, "Invoice.pdf");

				using (var writer = new PdfWriter(export_File))
				{
					using (var pdf = new PdfDocument(writer))
					{

						var document = new Document(pdf);

						//Adding contents in PDF
						//Invoice Header
						document.Add(new Paragraph("Shine Master Invoice"));
						document.Add(new Paragraph("Invoice number: " + InvoiceId));
						document.Add(new Paragraph(InvoiceDate.ToString()));
						document.Add(new Paragraph("-------------------"));
						//Customer Details
						document.Add(new Paragraph("Customer Details"));
						document.Add(new Paragraph("Customer Name: " + InvoiceCustomerName));
						document.Add(new Paragraph("Email: " + InvoiceEmail));
						document.Add(new Paragraph("Address: " + InvoiceAddress));
						document.Add(new Paragraph("Post code: " + InvoicePostcode));
						document.Add(new Paragraph("-------------------"));
						//Services
						document.Add(new Paragraph("Services Details"));
						document.Add(new Paragraph("Chosen Services:"));

						for (int i = 0; i < item.Items.Count; i++)
						{
							int num = 1;
							document.Add(new Paragraph((num++) + ".) " + item.Items[i].SubItems[0].Text + "--->" + item.Items[i].SubItems[1].Text));
						}
						//Notes
						document.Add(new Paragraph("Notes: "));
						document.Add(new Paragraph(InvoiceNotes));

						//Payment details
						document.Add(new Paragraph("Payment Details:"));

						document.Add(new Paragraph(InvoicePaymentDetails_1));
						document.Add(new Paragraph(InvoicePaymentDetails_2));


						//Price
						document.Add(new Paragraph("Discount given: " + InvoiceDiscountGiven + "%"));
						document.Add(new Paragraph("-------------------"));
						document.Add(new Paragraph("Total Price: " + InvoiceTotalPrice));

					}

				}

				//Closing invoice Form
				foreach (Form form in System.Windows.Forms.Application.OpenForms)
				{

					if (form is Invoice_Form)
					{
						form.Close();
						break;
					}
				}

				Form_Menu openHome = new Form_Menu();

				openHome.Show();


			}

			//If cant be saved
			catch
			{
				MessageBox.Show("Cannot Save PDF into file");
			}

		}




	}

}
